---
title: 打开图像
layout: page
---
## Menus > File

### Menus > File > New
新建图像，填写长度，宽度，类型，以及层数，大于0则当作图像栈
![](http://home.imagepy.org/manual/new.png "new image")

### Menus > File > Open
从对话框通过交互选取一张图片打开
![](http://home.imagepy.org/manual/open.png "open image")

### Menus > File > Open Url
从网络资源获取一张图片用 ImagePy 打开
![](http://home.imagepy.org/manual/url.png "open url")

### Menus > Import > Sequence
导入 MicroCT 图像序列
![](http://home.imagepy.org/manual/sequence.png "sequence")

### Menus > Import > Save
保存图像，将会弹出文件对话框，选择路径和文件名。

### Menus > Import > Save As > Save Sequence
将图像栈保存为顺序编号的图片组